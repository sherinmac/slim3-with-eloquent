<?php

$db_host = 'localhost';
$db_name = 'user_db';
$db_user = 'root';
$db_pass = '';