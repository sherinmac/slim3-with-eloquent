<?php

namespace User\Models;

class User extends \Illuminate\Database\Eloquent\Model
{

}